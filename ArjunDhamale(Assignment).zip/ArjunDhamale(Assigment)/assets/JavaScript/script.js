const activateBtn = document.querySelector(".activate-btn");
// Add a 'click' event listener to the button
activateBtn.addEventListener("click", () => {
    alert("Activated Successfully!");
});